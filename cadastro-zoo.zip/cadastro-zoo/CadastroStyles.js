import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#e8f5e9',
    flexGrow: 1,
    justifyContent: 'center',
  },
  title: {
    fontSize: 28,
    color: '#2e7d32',
    marginBottom: 20,
    textAlign: 'center',
    fontWeight: 'bold',
    fontFamily: 'sans-serif-medium',
  },
  input: {
    backgroundColor: '#c8e6c9',
    padding: 12,
    marginVertical: 8,
    borderRadius: 12,
    fontSize: 16,
    color: '#1b5e20',
  },
  button: {
    backgroundColor: '#66bb6a',
    padding: 15,
    marginTop: 20,
    borderRadius: 20,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
});
