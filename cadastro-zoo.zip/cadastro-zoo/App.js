import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, Alert } from 'react-native';
import styles from './CadastroStyles';

const CadastroZoo = () => {
  const [form, setForm] = useState({
    nome: '',
    email: '',
    cpf: '',
    telefone: '',
    senha: '',
    repetirSenha: '',
  });

  const handleChange = (key, value) => {
    setForm({ ...form, [key]: value });
  };

  const handleCadastro = () => {
    if (form.senha !== form.repetirSenha) {
      Alert.alert('Erro', 'As senhas não coincidem!');
      return;
    }

  
    Alert.alert('Sucesso', 'Cadastro realizado com sucesso!');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Crie sua conta</Text>

      <TextInput
        style={styles.input}
        placeholder="Nome"
        placeholderTextColor="#a5d6a7"
        value={form.nome}
        onChangeText={(text) => handleChange('nome', text)}
      />
      <TextInput
        style={styles.input}
        placeholder="E-mail"
        placeholderTextColor="#a5d6a7"
        keyboardType="email-address"
        value={form.email}
        onChangeText={(text) => handleChange('email', text)}
      />
      <TextInput
        style={styles.input}
        placeholder="CPF"
        placeholderTextColor="#a5d6a7"
        keyboardType="numeric"
        value={form.cpf}
        onChangeText={(text) => handleChange('cpf', text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Telefone"
        placeholderTextColor="#a5d6a7"
        keyboardType="phone-pad"
        value={form.telefone}
        onChangeText={(text) => handleChange('telefone', text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Senha"
        placeholderTextColor="#a5d6a7"
        secureTextEntry
        value={form.senha}
        onChangeText={(text) => handleChange('senha', text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Repetir Senha"
        placeholderTextColor="#a5d6a7"
        secureTextEntry
        value={form.repetirSenha}
        onChangeText={(text) => handleChange('repetirSenha', text)}
      />

      <TouchableOpacity style={styles.button} onPress={handleCadastro}>
        <Text style={styles.buttonText}>Cadastrar</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

export default CadastroZoo;
